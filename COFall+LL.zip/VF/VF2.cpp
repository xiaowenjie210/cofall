/*
 *References:
 
 *This program is based on McSplit (base version).
 *McCreesh, Ciaran, Patrick Prosser, and James Trimble. 
 "A Partitioning Algorithm for Maximum Common Subgraph Problems."
 *In IJCAI-17
 *you can download McSplit code from https://github.com/jamestrimble/ijcai2017-partitioning-common-subgraph
 
 *The variant algorithm McSplit+RL
 *Yanli Liu, Chu-Min Li, Jiang Hua, Kun He,
 *"A Learning based Branch and Bound for Maximum Common Subgraph related Problems",
 *In AAAI-20
 *you can download McSplit+RL code from https://github.com/JHL-HUST/McSplit-RL
 
 *This program is for MCS problem and MCCS problem based on a learning of branching vertices.
 *This program is free software. you can redistribute it and/or modify it for research.
 */


#include "graph_rank.h"

#include <algorithm>
#include <numeric>
#include <chrono>
#include <iostream>
#include <set>
#include <string>
#include <utility>
#include <vector>
#include <mutex>
#include <thread>
#include <condition_variable>
#include <atomic>
#include <cstring>

#include <argp.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#define VSCORE
//#define DEBUG
#define Best
using std::vector;
using std::cout;
using std::endl;

static void fail(std::string msg) {
    std::cerr << msg << std::endl;
    exit(1);
}


enum Heuristic { min_max, min_product };

/*******************************************************************************
                             Command-line arguments
*******************************************************************************/

static char doc[] = "Find a maximum clique in a graph in DIMACS format\vHEURISTIC can be min_max or min_product";
static char args_doc[] = "HEURISTIC FILENAME1 FILENAME2";
static struct argp_option options[] = {
    {"quiet", 'q', 0, 0, "Quiet output"},
    {"verbose", 'v', 0, 0, "Verbose output"},
    {"dimacs", 'd', 0, 0, "Read DIMACS format"},
    {"lad", 'l', 0, 0, "Read LAD format"},
    {"connected", 'c', 0, 0, "Solve max common CONNECTED subgraph problem"},
    {"directed", 'i', 0, 0, "Use directed graphs"},
    {"ranked", 'r', 0,0,"Use ranked query graph"},
    {"labelled", 'a', 0, 0, "Use edge and vertex labels"},
    {"vertex-labelled-only", 'x', 0, 0, "Use vertex labels, but not edge labels"},
    {"big-first", 'b', 0, 0, "First try to find an induced subgraph isomorphism, then decrement the target size"},
    {"timeout", 't', "timeout", 0, "Specify a timeout (seconds)"},
    { 0 }
};

static struct {
    bool quiet;
    bool verbose;
    bool dimacs;
    bool lad;
    bool connected;
    bool directed;
    bool ranked;
    bool edge_labelled;
    bool vertex_labelled;
    bool big_first;
    Heuristic heuristic;
    char *filename1;
    char *filename2;
    int timeout;
    int arg_num;
} arguments;

static std::atomic<bool> abort_due_to_timeout;

void set_default_arguments() {
    arguments.quiet = false;
    arguments.verbose = false;
    arguments.dimacs = false;
    arguments.lad = false;
    arguments.connected = false;
    arguments.directed = false;
    arguments.ranked = false;
    arguments.edge_labelled = false;
    arguments.vertex_labelled = false;
    arguments.big_first = false;
    arguments.filename1 = NULL;
    arguments.filename2 = NULL;
    arguments.timeout = 0;
    arguments.arg_num = 0;
}

static error_t parse_opt (int key, char *arg, struct argp_state *state) {
    switch (key) {
        case 'd':
            if (arguments.lad)
                fail("The -d and -l options cannot be used together.\n");
            arguments.dimacs = true;
            break;
        case 'l':
            if (arguments.dimacs)
                fail("The -d and -l options cannot be used together.\n");
            arguments.lad = true;
            break;
        case 'q':
            arguments.quiet = true;
            break;
        case 'v':
            arguments.verbose = true;
            break;
        case 'r':
            arguments.ranked = true;
            break;
        case 'c':
            if (arguments.directed)
                fail("The connected and directed options can't be used together.");
            arguments.connected = true;
            break;
        case 'i':
            if (arguments.connected)
                fail("The connected and directed options can't be used together.");
            arguments.directed = true;
            break;
        case 'a':
            if (arguments.vertex_labelled)
                fail("The -a and -x options can't be used together.");
            arguments.edge_labelled = true;
            arguments.vertex_labelled = true;
            break;
        case 'x':
            if (arguments.edge_labelled)
                fail("The -a and -x options can't be used together.");
            arguments.vertex_labelled = true;
            break;
        case 'b':
            arguments.big_first = true;
            break;
        case 't':
            arguments.timeout = std::stoi(arg);
            break;
        case ARGP_KEY_ARG:
            if (arguments.arg_num == 0) {
                if (std::string(arg) == "min_max")
                    arguments.heuristic = min_max;
                else if (std::string(arg) == "min_product")
                    arguments.heuristic = min_product;
                else
                    fail("Unknown heuristic (try min_max or min_product)");
            } else if (arguments.arg_num == 1) {
                arguments.filename1 = arg;
            } else if (arguments.arg_num == 2) {
                arguments.filename2 = arg;
            } else {
                argp_usage(state);
            }
            arguments.arg_num++;
            break;
        case ARGP_KEY_END:
            if (arguments.arg_num == 0)
                argp_usage(state);
            break;
        default: return ARGP_ERR_UNKNOWN;
    }
    return 0;
}

static struct argp argp = { options, parse_opt, args_doc, doc };

/*******************************************************************************
                                     Stats
*******************************************************************************/

unsigned long long nodes{ 0 };
unsigned long long cutbranches{0};
unsigned long long conflicts=0;
unsigned long long total_maps=0;
clock_t bestfind;
unsigned long long bestnodes=0,bestcount=0;
int dl=0;
bool flag=true;
clock_t start;
unsigned long long n_compulsory{ 0 };
unsigned long long incub_size{ 0 };
vector<int> negative_vertices;

/*******************************************************************************
                                 MCS functions
*******************************************************************************/


struct VtxPair {
    int v;
    int w;
    VtxPair(int v, int w): v(v), w(w) {}
};

int sum(const vector<int> & vec) {
    return std::accumulate(std::begin(vec), std::end(vec), 0);
}


struct Bidomain {
    int l,        r;        // start indices of left and right sets
    int left_len, right_len;
    bool is_adjacent;
    Bidomain(int l, int r, int left_len, int right_len, bool is_adjacent):
            l(l),
            r(r),
            left_len (left_len),
            right_len (right_len),
            is_adjacent (is_adjacent) {};
};

void show(const vector<VtxPair>& current, const vector<Bidomain> &domains,
        const vector<int>& left, const vector<int>& right)
{
    cout << "Nodes: " << nodes << std::endl;
    cout << "Length of current assignment: " << current.size() << std::endl;
    cout << "Current assignment:";
    for (unsigned int i=0; i<current.size(); i++) {
        cout << "  (" << current[i].v << " -> " << current[i].w << ")";
    }
    cout << std::endl;
    for (unsigned int i=0; i<domains.size(); i++) {
        struct Bidomain bd = domains[i];
        cout << "Left  ";
        for (int j=0; j<bd.left_len; j++)
            cout << left[bd.l + j] << " ";
        cout << std::endl;
        cout << "Right  ";
        for (int j=0; j<bd.right_len; j++)
            cout << right[bd.r + j] << " ";
        cout << std::endl;
    }
    cout << "\n" << std::endl;
}

bool check_sol(const Graph & g0, const Graph & g1 , const vector<VtxPair> & solution) {
    vector<bool> used_left(g0.n, false);
    vector<bool> used_right(g1.n, false);
    for (unsigned int i=0; i<solution.size(); i++) {
        struct VtxPair p0 = solution[i];
        if (used_left[p0.v] || used_right[p0.w])
            return false;
        used_left[p0.v] = true;
        used_right[p0.w] = true;
        if (g0.label[p0.v] != g1.label[p0.w])
            return false;
        for (unsigned int j=i+1; j<solution.size(); j++) {
            struct VtxPair p1 = solution[j];
            if (g0.adjmat[p0.v][p1.v] != g1.adjmat[p0.w][p1.w])
                return false;
        }
    }
    return true;
}



bool cal_bound(vector<VtxPair> &incumbent, vector<int>&Q_matched, vector<int>&D_matched){
    bool bound_1 = (Q_matched.size()-sum(Q_matched))> (D_matched.size()-sum(D_matched));
    if (bound_1) {
        //cout<<"bound 1\n";
        //cout<<  nodes;
        //for (unsigned int i=0; i<incumbent.size(); i++) {
        //    cout <<"  (" << incumbent[i].v << " -> " << incumbent[i].w << ")";
        //}
        //cout << "\n";
        return true;}
    int num_q = Q_matched.size();
    bool bound_2 = (num_q==sum(Q_matched));
    if (bound_2) {
        //cout<<"bound 2"<<endl;
        //cout<<"current iteration: "<<nodes<<endl;
        //for (unsigned int i=0; i<incumbent.size(); i++) {
        //    cout <<"  (" << incumbent[i].v << " -> " << incumbent[i].w << ")";
        //}
        //cout << "\n";
        return true;}
    //bound_2
    return false;
}


//first find out the compulsory vertex.

int select_nq(const Graph & Q,vector<VtxPair> & current,vector<int>&Q_matched){
    int q_idx = 0;
    if (current.size()==0) return q_idx;
    for (int i=0; i<Q.n; i++) {
        if (Q_matched[i]==1) continue;

        for (unsigned int j=0; j<current.size(); j++) {
            int q = current[j].v;
            if (Q.adjmat[i][q]) {
                q_idx = i;
                return q_idx;}
            }
        //return i; //non-connected vertex.
        }
    return -1;
    }


//mapping里的邻接点并集减去mapping里的点即可
vector<int> cal_dcandidate(const Graph & D,vector<VtxPair> & current,vector<int>&D_matched){

    vector<int> candidate_nd;

    if (current.size()==0){
        for (int i=0; i<D.n; i++){candidate_nd.push_back(i);}
        return candidate_nd;
    }
    
    for (int i=0; i<D.n; i++){
        if (D_matched[i]==1) continue;
        for (unsigned int j=0; j<current.size(); j++) {
            int d = current[j].w;
            if (D.adjmat[i][d]){
                candidate_nd.push_back(i);
                break;
                }
            }
        }
    return candidate_nd;
    }



bool match_cert(const Graph & Q, const Graph & D,int&q_idx, int&d_idx,vector<VtxPair> & current){
    bool cert_1 = Q.label[q_idx] != D.label[d_idx];
    if (cert_1) return false;
    bool cert_2 = Q.n_adj[q_idx] > D.n_adj[d_idx];
    if (cert_2) {
        cutbranches++; //pruning technology.
        return false;}
//cert_3
    for (unsigned int i=0; i<current.size(); i++) {
        int q = current[i].v;
        int d = current[i].w;
        if (Q.adjmat[q_idx][q] != D.adjmat[d_idx][d])
            return false;
    }
    return true;
};



void solve(const Graph & Q, const Graph & D, vector<int> &Q_matched,vector<int>&D_matched, vector<VtxPair> & incumbent, vector<VtxPair> & current)
{nodes ++;
    if(arguments.timeout && double(clock() - start) / CLOCKS_PER_SEC > arguments.timeout)
    {
        cout <<"time out" <<endl;
        exit(0);
    }

    if (current.size() >= incumbent.size()) {
        incumbent = current;
        incub_size = incumbent.size();
    }

    bool bound = cal_bound(incumbent, Q_matched, D_matched);

    if (bound){
        //cout<<"find the optimal solution for SI\n";
        total_maps++;
        if (flag){
            bestcount = cutbranches+1;
            bestnodes=nodes;
            bestfind=clock();}
        flag = false;
        return;
    }
    else{
        int q_idx = select_nq(Q, current, Q_matched);

        Q_matched[q_idx] = 1;
        vector<int> candidate_nd;
        candidate_nd = cal_dcandidate(D, current, D_matched);
        int num_cand = candidate_nd.size();
        for (int i=0; i < num_cand; i++) {
            int d_idx = candidate_nd[i];
            if (match_cert(Q, D, q_idx, d_idx, current)){
                D_matched[d_idx] = 1;
                current.push_back(VtxPair(q_idx, d_idx));
                solve(Q, D, Q_matched,D_matched,incumbent, current);
                VtxPair pr = current.back();
                current.pop_back();
                D_matched[pr.w] = 0;}
        }
        Q_matched[q_idx] = 0;
    }
    //solve(Q, D, Q_matched,D_matched,incumbent, current); //相当于记住了新的incumbent，但current是没有当前q_idx的，看没有q_idx的组合里面是不是有更大的合适的解。要去找下一个q_idx了。一个solve解决一个q_idx。这里要有一个q_idx更新方式。
}

vector<VtxPair> VF_COF(const Graph & Q, const Graph &D) {

    vector<VtxPair> incumbent;
    vector<VtxPair> current;
    vector<int> Q_matched(Q.n, 0);
    vector<int> D_matched(D.n, 0);
    
    solve(Q, D, Q_matched,D_matched,incumbent,current);
    
    return incumbent;
}

vector<int> calculate_degrees(const Graph & g) {
    vector<int> degree(g.n, 0);
    for (int v=0; v<g.n; v++) {
        for (int w=0; w<g.n; w++) {
            unsigned int mask = 0xFFFFu;
            if (g.adjmat[v][w] & mask) degree[v]++;
            if (g.adjmat[v][w] & ~mask) degree[v]++;
        }
    }
    return degree;
}



int main(int argc, char** argv) {
    set_default_arguments();
    argp_parse(&argp, argc, argv, 0, 0, 0);
   
    char format = arguments.dimacs ? 'D' : arguments.lad ? 'L' : 'B';
    struct Graph g0 = readGraph(arguments.filename1, format, arguments.directed,
            arguments.edge_labelled, arguments.vertex_labelled,false);
    struct Graph g1 = readGraph(arguments.filename2, format, arguments.directed,
            arguments.edge_labelled, arguments.vertex_labelled,false);

    std::condition_variable timeout_cv;
    abort_due_to_timeout.store(false);
    bool aborted = false;
    
    

    vector<int> g0_deg = calculate_degrees(g0);
    vector<int> g1_deg = calculate_degrees(g1);

    vector<int> vv0(g0.n);
    std::iota(std::begin(vv0), std::end(vv0), 0);
    bool g1_dense = sum(g1_deg) > g1.n*(g1.n-1);
    std::stable_sort(std::begin(vv0), std::end(vv0), [&](int a, int b) {
        if (g0.rank[a]!= g0.rank[b]) return g0.rank[a] > g0.rank[b];
        else return g1_dense ? (g0_deg[a]<g0_deg[b]) : (g0_deg[a]>g0_deg[b]);
    });

    vector<int> vv1(g1.n);
    std::iota(std::begin(vv1), std::end(vv1), 0);
    bool g0_dense = sum(g0_deg) > g0.n*(g0.n-1);
    std::stable_sort(std::begin(vv1), std::end(vv1), [&](int a, int b) {
        return g0_dense ? (g1_deg[a]<g1_deg[b]) : (g1_deg[a]>g1_deg[b]);
    });

    struct Graph g0_sorted = induced_subgraph(g0, vv0,true);
    struct Graph g1_sorted = induced_subgraph(g1, vv1,false);

    start=clock();
    vector<VtxPair> solution = VF_COF(g0_sorted, g1_sorted);
    clock_t time_elapsed = clock()-start;
  
    for (auto& vtx_pair : solution) {
        vtx_pair.v = vv0[vtx_pair.v];
        vtx_pair.w = vv1[vtx_pair.w];
    }
    
    clock_t time_find = bestfind - start;

    if (!check_sol(g0, g1, solution))
        fail("*** Error: Invalid solution\n");

    cout << "Solution size " << solution.size() << std::endl;
    cout << "Total maps:   "<<total_maps<< endl;
    cout<<"Nodes:                      " << nodes << endl;
    cout<<"Cut branches:               "<<cutbranches<<endl;
    cout<<"Conflicts:                    " <<conflicts<< endl;

    cout << "CPU time (ms): " <<  time_elapsed<< std::endl;
    cout << "FindBest time (ms): " <<  time_find<< std::endl;
  #ifdef Best
    cout<<"Best nodes:                 "<<bestnodes<<endl;
    cout<<"Best count:                 "<<bestcount<<endl;
#endif
    if (aborted)
        cout << "TIMEOUT" << endl;
}

