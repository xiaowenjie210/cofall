# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

import matplotlib.pyplot as plt
import numpy as np
import os
import re
from tqdm import tqdm


"""
method = {'cofall':{'facebook_ct1':{"5","10","15"},'MSRC_9':{"5","10","15"},'MUTAG':{"5","10","15"}},
          'cofall+ll':{'facebook_ct1':{"5","10","15"},'MSRC_9':{"5","10","15"},'MUTAG':{"5","10","15"}},
          'cofall+rl':{'facebook_ct1':{"5","10","15"},'MSRC_9':{"5","10","15"},'MUTAG':{"5","10","15"}},
          'cofall+ultra':{'facebook_ct1':{"5","10","15"},'MSRC_9':{"5","10","15"},'MUTAG':{"5","10","15"}},
          'vf_cof':{'facebook_ct1':{"5","10","15"},'MSRC_9':{"5","10","15"},'MUTAG':{"5","10","15"}}}

avg_method = {'cofall':{'facebook_ct1':{"5","10","15"},'MSRC_9':{"5","10","15"},'MUTAG':{"5","10","15"}},
          'cofall+ll':{'facebook_ct1':{"5","10","15"},'MSRC_9':{"5","10","15"},'MUTAG':{"5","10","15"}},
          'cofall+rl':{'facebook_ct1':{"5","10","15"},'MSRC_9':{"5","10","15"},'MUTAG':{"5","10","15"}},
          'cofall+ultra':{'facebook_ct1':{"5","10","15"},'MSRC_9':{"5","10","15"},'MUTAG':{"5","10","15"}},
          'vf_cof':{'facebook_ct1':{"5","10","15"},'MSRC_9':{"5","10","15"},'MUTAG':{"5","10","15"}}}


for key in tqdm(method.keys()):
    file_list = os.listdir(key)
    for file in tqdm(file_list):
        task = file.split("_qu")[0]
        with open(os.path.join(key,file)) as f:
            part = re.findall("size\d+",file)[0][4:]
            #part = re.findall("part\d+\.\d+",file)[0][4:]
            for line in f.readlines():
                if "time out" in line:
                    method[key][task][part].append(1000)
                    break
                if "CPU" in line:
                    n = re.findall("\d+",line)
                    method[key][task][part].append(eval(n[0]))

for key in method.keys():
    for task in method[key].keys():
        for size in method[key][task].keys():
            avg_method[key][task][size]=sum(method[key][task][size])/len(method[key][task][size])


print(avg_method)

"""

dic = {

       'vf_cof': {'facebook_ct1': [],
                  'MSRC_9': {},
                  'MUTAG': {}},
       'cofall': {'facebook_ct1': [],
                   'MSRC_9': {},
                   'MUTAG': {}},
    'cofall+rl': {
        'facebook_ct1': [],
        'MSRC_9': {},
        'MUTAG': {}},
    'cofall+ll': {
        'facebook_ct1': [],
        'MSRC_9': {},
        'MUTAG': {}},

    'cofall+ultra': {
        'facebook_ct1': [],
        'MSRC_9': {},
        'MUTAG': {5}},
}



labels = ['0.0','0.2','0.4','0.6','0.8','1.0']

MQO =np.array( [48268983.161023945, 48281834.220891826, 48281507.644921556, 48327600.6895128,  48167368.0342692,  48202222.015689515])/1000
b = np.array( [343948.20650351996, 417780.63904729957, 3093196.126732004, 8477700.696873903,
                                    5939420.604287791, 343227.84311096213])/1000
c =np.array([315575.5325067024, 301314.4710023466, 2683951.969277515, 7345736.145155649, 5423037.290205999,
                         315226.2315683646])/1000
d =np.array([461.3742043551089, 5025.613400335008, 674464.3620516259, 432846.4339303819, 571750.1146366427,
                         453.6077051926298])/1000
e =np.array([69824.05259631491, 55847.042546063654, 87251.12529313233, 72772.3500837521, 50447.25427135678,
                         28717.18726968174])/1000
"""
MQO =np.array( [20728.782805429862, 20841.138763197585, 20777.460030165912, 20877.547511312216,  20767.574660633483,  20453.206636500756])/1000
b = np.array( [107.51885369532428, 316.69834087481144, 9601.179487179486, 962486.2021116138,
                              750030.371040724, 106.56711915535445])/1000
c =np.array([118.42684766214178, 266.31523378582204, 3660.8763197586727, 22209.01055806938, 496058.2911010558,
                   117.68627450980392])/1000
d =np.array([106.66365007541478, 299.62745098039215, 4430.461538461538, 79807.47360482655, 169911.55354449473,
                   106.22171945701358])/1000
e =np.array([16896.51583710407, 8274.671191553545, 21080.787330316743, 44119.78431372549, 44491.666666666664,
                   10062.458521870287])/1000

MQO =np.array( [2650.96875, 2823.09375, 2826.8541666666665, 2882.6432291666665,  2827.8411458333335,  2851.1796875])/1000
b = np.array( [47.8828125, 76.71875, 451.1432291666667, 13061.544270833334, 40640.817708333336,
                             44.927083333333336])/1000
c =np.array([46.4609375, 77.58854166666667, 138.8359375, 147.64583333333334, 9097.78125, 45.78125])/1000
d =np.array([42.734375, 80.68489583333333, 113.47916666666667, 95.76822916666667, 52.723958333333336,
                  42.580729166666664])/1000
e =np.array([2746.5182291666665, 2230.9088541666665, 4749.708333333333, 5557.828125, 4824.677083333333,
                  3757.583333333333])/1000
"""

"""
labels =['5','10','15']

MQO =np.array( [24852.486599664993,  63880617.65741789, 111106803.15318628])/1000
b = np.array( [122.0931323283082,  423862.6344700151, 9029977.393049086])/1000
c =np.array([133.13835845896148,  203031.2953820319, 8109753.631100819])/1000
d =np.array([103.09463986599665,  370.2404087786899, 846226.2885039905])/1000
e =np.array([970.0333333333333,  18555.721440536014, 162903.7512562814])/1000


MQO =np.array( [3100.1432880844645,  29479.74660633484, 29642.965309200605])/1000
b = np.array( [59.35294117647059,  1225.740573152338, 860039.1749622927])/1000
c =np.array([61.9683257918552,  423.9894419306184, 260729.34539969833])/1000
d =np.array([59.81598793363499,  367.25113122171945, 126903.93363499246])/1000
e =np.array([339.2021116138763,  6551.863499245852, 65571.87631975867])/1000

MQO =np.array( [3100.1432880844645,  29479.74660633484, 29642.965309200605])/1000
b = np.array( [59.35294117647059,  1225.740573152338, 860039.1749622927])/1000
c =np.array([61.9683257918552,  423.9894419306184, 260729.34539969833])/1000
d =np.array([59.81598793363499,  367.25113122171945, 126903.93363499246])/1000
e =np.array([339.2021116138763,  6551.863499245852, 65571.87631975867])/1000

"""



x = np.arange(len(labels))  # 标签位置
width = 0.1  # 柱状图的宽度

#labels = [,,,,'cofall+ultra']
fig, ax = plt.subplots()
rects1 = ax.bar(x - width * 2, MQO, width, label='vf_cof', hatch="...", color='w', edgecolor="k")
rects2 = ax.bar(x - width + 0.01, b, width, label='cofall', hatch="oo", color='w', edgecolor="k")
rects3 = ax.bar(x + 0.02, c, width, label='cofall+rl', hatch="++", color='w', edgecolor="k")
rects4 = ax.bar(x + width + 0.03, d, width, label='cofall+ll', hatch="XX", color='w', edgecolor="k")
rects5 = ax.bar(x + width * 2 + 0.04, e, width, label='cofall+ultra', hatch="**", color='w', edgecolor="k")

# 为y轴、标题和x轴等添加一些文本。
ax.set_ylabel('Runing time (ms)', fontsize=16)
ax.set_xlabel('Compulsory proportion', fontsize=16)
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.legend()
ax.set_ylim(10**-2, 10**6)
ax.set_yscale('log')


fig.tight_layout()
plt.show()
