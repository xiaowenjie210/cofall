import os
from tqdm import tqdm



method = {'cofall':{'facebook_ct1':0,'MSRC_9':0,'MUTAG':0},
          'cofall+ll':{'facebook_ct1':0,'MSRC_9':0,'MUTAG':0},
          'cofall+rl':{'facebook_ct1':0,'MSRC_9':0,'MUTAG':0},
          'cofall+ultra':{'facebook_ct1':0,'MSRC_9':0,'MUTAG':0},
          'vf_cof':{'facebook_ct1':0,'MSRC_9':0,'MUTAG':0}}
size = {'15':[],'10':[],'5':[]}
part = {'0.0':[],'0.2':[],'0.4':[],'0.6':[],'0.8':[],'1.0':[],}

for key in tqdm(method.keys()):
    file_list = os.listdir(key)
    for file in tqdm(file_list):
        task = file.split("_qu")[0]
        with open(os.path.join(key,file)) as f:
            for line in f.readlines():
                if "time out" in line:
                    method[key][task]+=1
print(method)
