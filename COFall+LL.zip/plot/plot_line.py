import re

import matplotlib.pyplot as plt
import numpy as np
import os
from tqdm import tqdm
import re
from matplotlib.pyplot import MultipleLocator

import matplotlib.pyplot as plt
from matplotlib.patches import ConnectionPatch
import numpy as np


def zone_and_linked(ax, axins, zone_left, zone_right, x, y, linked='bottom',
                    x_ratio=0.05, y_ratio=0.05):
    xlim_left = x[zone_left] - (x[zone_right] - x[zone_left]) * x_ratio
    xlim_right = x[zone_right] + (x[zone_right] - x[zone_left]) * x_ratio

    y_data = np.hstack([yi[zone_left:zone_right] for yi in y])
    ylim_bottom = np.min(y_data) - (np.max(y_data) - np.min(y_data)) * y_ratio
    ylim_top = np.max(y_data) + (np.max(y_data) - np.min(y_data)) * y_ratio

    axins.set_xlim(xlim_left, xlim_right)
    axins.set_ylim(ylim_bottom, ylim_top)

    ax.plot([xlim_left, xlim_right, xlim_right, xlim_left, xlim_left],
            [ylim_bottom, ylim_bottom, ylim_top, ylim_top, ylim_bottom], "black")

    if linked == 'bottom':
        xyA_1, xyB_1 = (xlim_left, ylim_top), (xlim_left, ylim_bottom)
        xyA_2, xyB_2 = (xlim_right, ylim_top), (xlim_right, ylim_bottom)
    elif linked == 'top':
        xyA_1, xyB_1 = (xlim_left, ylim_bottom), (xlim_left, ylim_top)
        xyA_2, xyB_2 = (xlim_right, ylim_bottom), (xlim_right, ylim_top)
    elif linked == 'left':
        xyA_1, xyB_1 = (xlim_right, ylim_top), (xlim_left, ylim_top)
        xyA_2, xyB_2 = (xlim_right, ylim_bottom), (xlim_left, ylim_bottom)
    elif linked == 'right':
        xyA_1, xyB_1 = (xlim_left, ylim_top), (xlim_right, ylim_top)
        xyA_2, xyB_2 = (xlim_left, ylim_bottom), (xlim_right, ylim_bottom)

    con = ConnectionPatch(xyA=xyA_1, xyB=xyB_1, coordsA="data",
                          coordsB="data", axesA=axins, axesB=ax)
    axins.add_artist(con)
    con = ConnectionPatch(xyA=xyA_2, xyB=xyB_2, coordsA="data",
                          coordsB="data", axesA=axins, axesB=ax)
    axins.add_artist(con)


method = {'cofall':{'facebook_ct1':[],'MSRC_9':[],'MUTAG':[]},
          'cofall+ll':{'facebook_ct1':[],'MSRC_9':[],'MUTAG':[]},
          'cofall+rl':{'facebook_ct1':[],'MSRC_9':[],'MUTAG':[]},
          'cofall+ultra':{'facebook_ct1':[],'MSRC_9':[],'MUTAG':[]},
          'vf_cof':{'facebook_ct1':[],'MSRC_9':[],'MUTAG':[]}}
size = {'15':[],'10':[],'5':[]}
part = {'0.0':[],'0.2':[],'0.4':[],'0.6':[],'0.8':[],'1.0':[],}


for key in tqdm(method.keys()):
    file_list = os.listdir(key)
    for file in (file_list):
        task = file.split("_qu")[0]
        with open(os.path.join(key,file)) as f:
            for line in f.readlines():
                if "CPU" in line:
                    n = re.findall("\d+",line)
                    method[key][task].append(eval(n[0]))

marker_list = ['*','o','x','s','^']
str_list = ['vf_cof','cofall','cofall+rl','cofall+ll','cofall+ultra']
word_list = ['facebook_ct1','MSRC_9','MUTAG']

range_idx = range(3)
color_list = ['r','b','g','c','k']


for k,item in zip(range_idx,word_list):
    fig, ax = plt.subplots(1, 1)
    y,x_0 = [],[]
    for string,mark,col in zip(str_list,marker_list,color_list):
        list_1 = sorted(method[string][item])
        if string=="cofall+ultra":
            list_1 =[i/100000000 for i in list_1]
        else:
            list_1 = [i / 1000000 for i in list_1]
        y.append(list_1)
        x =[i+1 for i in range(len(list_1))]
        if len(x)>len(x_0):
            x_0 = x
        ax.plot(list_1,x, color=col, label=string)#,marker=mark,markersize=1)
    ax.set_ylabel("The accumulated solved instances number")
    ax.set_xlabel("Running tims(s)")
    ax.legend(loc="right", bbox_to_anchor=(1,0.35))
    ax.set_xlim(10 ** -5, 10 ** 3)
    ax.set_xscale('log')
    #axins = ax.inset_axes((0.4, 0.1, 0.4, 0.3))
    #zone_and_linked(ax, axins, 0, 20, x_0, y, 'bottom')
    plt.show()

"""
for string,mark,col in zip(str_list,marker_list,color_list):
    for k,item in zip(range_idx[:1],word_list[:1]):
        ax = axes[k]
        list_1 = sorted(method[string][item])
        list_1 =[i/1000 for i in list_1]
        x =[i+1 for i in range(len(list_1))]
        ax.plot(list_1,x, color=col, label=string,marker=mark,markersize=1)

for k,string in zip(range_idx[:1],word_list[:1]):
    axes[k].set_ylabel("The accumulated solved instances number")
    axes[k].set_xlabel("Running tims(s)")
    axes[k].title.set_text(string)

axes[0].legend(loc="right", bbox_to_anchor=(1,0.85), bbox_transform=axes[0].transAxes)
#axes[1].legend(loc="right", bbox_to_anchor=(1,0.8), bbox_transform=axes[1].transAxes)
#axes[2].legend(loc="right", bbox_to_anchor=(1,0.8), bbox_transform=axes[2].transAxes)
plt.subplots_adjust(wspace=0.5,hspace=0)
plt.show()
"""

