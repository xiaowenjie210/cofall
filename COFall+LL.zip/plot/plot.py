import re

import matplotlib.pyplot as plt
import numpy as np
import os
from tqdm import tqdm
import re
from matplotlib.pyplot import MultipleLocator

import matplotlib.pyplot as plt
from matplotlib.patches import ConnectionPatch
import numpy as np

method = {'cofall':{'facebook_ct1':{"5","10","15"},'MSRC_9':{"5","10","15"},'MUTAG':{"5","10","15"}},
          'cofall+ll':{'facebook_ct1':{"5","10","15"},'MSRC_9':{"5","10","15"},'MUTAG':{"5","10","15"}},
          'cofall+rl':{'facebook_ct1':{"5","10","15"},'MSRC_9':{"5","10","15"},'MUTAG':{"5","10","15"}},
          'cofall+ultra':{'facebook_ct1':{"5","10","15"},'MSRC_9':{"5","10","15"},'MUTAG':{"5","10","15"}},
          'vf_cof':{'facebook_ct1':{"5","10","15"},'MSRC_9':{"5","10","15"},'MUTAG':{"5","10","15"}}}

avg_method = {'cofall':{'facebook_ct1':{"5","10","15"},'MSRC_9':{"5","10","15"},'MUTAG':{"5","10","15"}},
          'cofall+ll':{'facebook_ct1':{"5","10","15"},'MSRC_9':{"5","10","15"},'MUTAG':{"5","10","15"}},
          'cofall+rl':{'facebook_ct1':{"5","10","15"},'MSRC_9':{"5","10","15"},'MUTAG':{"5","10","15"}},
          'cofall+ultra':{'facebook_ct1':{"5","10","15"},'MSRC_9':{"5","10","15"},'MUTAG':{"5","10","15"}},
          'vf_cof':{'facebook_ct1':{"5","10","15"},'MSRC_9':{"5","10","15"},'MUTAG':{"5","10","15"}}}


key = 'cofall+ultra'
file_list = os.listdir(key)
print(len(file_list))
key_list = []
for file in tqdm(file_list[:5]):
    task = file.split("_qu")[0]
    with open(os.path.join(key,file)) as f:
        for line in f.readlines():
            if "Solution" in line:
                size= re.findall("size\s\d+",line)[0][4:]
                if eval(size) in [5,10,15]:
                    key_list.append(file)
                    break

print(len(key_list))


for key in method.keys():
    for file in key_list:
        with open(os.path.join(key, file)) as f:
            u_nodes = []
            for line in f.readlines():
                if "Nodes: " in line:
                    num = re.findall("\d+",line)[0]
                    u_nodes.append(eval(num))
    print(key," : ",sum(u_nodes)/len(u_nodes))