import numpy as np
from tqdm import tqdm
from collections import Counter

graph_indicator = []
with open("AIDS/AIDS_graph_indicator.txt") as f:
    for line in f.readlines():
        graph_indicator.append(line[:-1])

edge_dict = {}
with open("AIDS/edge_class.txt") as f:
    for line in f.readlines():
        edge = line.strip().split(",")
        edge = list(map(int, edge))
        if str(edge[2]+1) in edge_dict:
            edge_dict[str(edge[2]+1)].append(edge[:2])
        else:
            edge_dict[str(edge[2]+1)] = [edge[:2]]
counter = Counter(graph_indicator)
counters = {}
edges,nodes = 0,0
for key,item in counter.items():
    if item>15:
        counters[key] = {"num_nodes":int,"edges":[]}
        counters[key]["num_nodes"]= item
        counters[key]["edges"] = edge_dict[key]
        nodes += item
        edges += len(edge_dict[key])
##############graph statistics#################################
print("AIDS contains graph: ",len(counters))
print("AIDS average nodes: ", nodes/len(counters))
print("AIDS average edges: ", edges/len(counters))
##################subgraph generator###########################



for key,item in tqdm(counters.items()):
    a = np.array(item["edges"])
    edge_list = a - np.min(a)

    total_edge = 0
    output_edge = []
    for i in range(item["num_nodes"]):
        adj = []
        for edge in edge_list:
            if i in edge:
                adj.extend(edge)
        adjs = list(set(adj))
        if adjs != []:
            total_edge+=1
            adjs.remove(i)
            sorted(adjs)
            adjs.insert(0,len(adjs))
            output_edge.append(adjs)
    with open("AIDS\data_graph\AID_{}".format(key),"w") as f:
        f.write(str(total_edge))
        f.write("\n")
        for edge in output_edge:
            for edge_item in edge:
                f.write(str(edge_item))
                f.write(" ")
            f.write("\n")










