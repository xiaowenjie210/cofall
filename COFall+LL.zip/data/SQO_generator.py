import re

import numpy as np
from tqdm import tqdm
from collections import Counter
import networkx as nx
import random
import time
import os
import matplotlib.pyplot as plt
from itertools import combinations


path = "./query_graph"

for file_name in tqdm(os.listdir(path)[:50]):
    L_o = []
    L_c = []
    size = eval(re.findall("size\d+",file_name)[0][4:])
    part = eval(re.findall("part\d+\.\d+",file_name)[0][4:])
    if (size*(1-part)<=6 and (size*(1-part))>=1):
        content = []
        with open(os.path.join(path,file_name)) as f:
            readlines = f.readlines()
            for line in readlines[1:(size+1)]:
                content.append(line)
            i=0
            for line in readlines[(size+1):]:
                if eval(line) ==0:
                    L_o.append(i)
                else:
                    L_c.append(i)
                i+=1
        induced_graph_index = 0
        if not os.path.exists("./conventional_query/{}/".format(file_name)):
            os.makedirs("./conventional_query/{}/".format(file_name))
        result_list = sum([list(map(list, combinations(L_o, i))) for i in range(len(L_o) + 1)], [])
        for l in result_list:
            #flag= False
            new_content,copy_content,extd_l = [],[],[]
            L = L_c.copy()
            L.extend(l)
            for i in L:
                copy_content.append(content[i])
            str_L = list(map(str,L))
            for item in copy_content:
                new_item = []
                item = item.strip().split(" ")[1:]
                for it in item:
                    if it in str_L:
                        new_item.append(int(it))
            #    if len(new_item)==0:
            #        flag = True
                new_content.append(new_item)
                extd_l.extend(new_item)
            #if flag:
            #    continue
            induced_graph_index+=1
            str_index = str(induced_graph_index).zfill(4)
            index_l = list(set(extd_l))

            new_cont = []
            for cl in new_content:
                new_it = []
                for rl in cl:
                    new_it.append(index_l.index(rl))
                new_it.insert(0,len(new_it))
                new_cont.append(new_it)


            with open("./conventional_query/{}/{}".format(file_name,str_index),"w") as f:
                f.write(str(len(new_content)))
                f.write("\n")
                for cont in new_content:
                    for edge_item in cont:
                        f.write(str(edge_item))
                        f.write(" ")
                    f.write("\n")