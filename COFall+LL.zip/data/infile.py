import os
import re

instance_list = []
task = "AIDS"
query_path = "./query_graph/"
data_path = "./data_graph/"
"""
for file in os.listdir(data_path):
    a = re.findall("AID_\d+",file)[0][4:]
    if len(a) <4:
        new_name = "AID_"+a.zfill(4)
        os.rename(os.path.join(data_path,file),os.path.join(data_path,new_name))

for file in os.listdir(query_path):
    a = re.findall("AID_query\d+",file)[0][9:]
    c = re.findall("_size\d+_part\d\.\d",file)
    if c:
        new_name = "AID_query"+a.zfill(4)+c[0]
    else:
        new_name = "AID_query"+a.zfill(4) +re.findall("_size\d+_part\d",file)[0]+".0"
    os.rename(os.path.join(query_path,file),os.path.join(query_path,new_name))

instance_list = []

for file in os.listdir(query_path):

    d_n = [file.split("_", 2)[0],file.split("_",2)[1].replace("query","")]

    q = "/home/star/data/{}/query_graph/{}".format(task,file)
    d = "/home/star/data/{}/data_graph/{}".format(task,"_".join(d_n))

    item = " ".join([file,q,d,"1"])
    instance_list.append(item)


with open("{}_mkdata.txt".format(task),"w") as f:
    for i in instance_list:
        f.write(i+"\n")
"""

path ="conventional_query"
for file in os.listdir(path):
    for item in os.listdir(os.path.join(path,file)):
        name = "_".join([file,item])
        d_n = [file.split("_", 2)[0], file.split("_", 2)[1].replace("query", "").zfill(4)]
        q = "/home/star/data/{}/{}".format(task, os.path.join(path,file,item).replace("\\","/"))
        d = "/home/star/data/{}/data_graph/{}".format(task,"_".join(d_n))
        item = " ".join([name,q,d,"1"])
        instance_list.append(item)
        print(item)


with open("{}_mkdata_conventional.txt".format(task),"w") as f:
    for i in instance_list:
        f.write(i+"\n")