import numpy as np
from tqdm import tqdm
from collections import Counter
import networkx as nx
import random
import time
import os
import matplotlib.pyplot as plt

graph_indicator = []
with open("AIDS_graph_indicator.txt") as f:
    for line in f.readlines():
        graph_indicator.append(line[:-1])

edge_dict = {}
with open("edge_class.txt") as f:
    for line in f.readlines():
        edge = line.strip().split(",")
        edge = list(map(int, edge))
        if str(edge[2]+1) in edge_dict:
            edge_dict[str(edge[2]+1)].append(edge[:2])
        else:
            edge_dict[str(edge[2]+1)] = [edge[:2]]
counter = Counter(graph_indicator)
counters = {}
edges,nodes = 0,0
for key,item in counter.items():
    if item>15:
        counters[key] = {"num_nodes":int,"edges":[]}
        counters[key]["num_nodes"]= item
        counters[key]["edges"] = edge_dict[key]
        nodes += item
        edges += len(edge_dict[key])


query_size_list = [5,10,15]
partition = [0,0.2,0.4,0.6,0.8,1.0]


def induced_node_list_generator(query_sizes,edge_lists,arr):
    induced_node_lists = []
    start = time.process_time()
    while len(induced_node_lists)<query_sizes and time.process_time() - start < 10:
        b = random.choice(arr)
        induced_node_lists = [b]
        k = 0
        while k < query_sizes-1 and time.process_time() - start < 5:
            for edge in edge_lists:
                if edge[0] in induced_node_lists and edge[1] not in induced_node_lists:
                    induced_node_lists.append(edge[1])
                    k += 1
                    break
    return induced_node_lists

def output_edge_list(size,given_edge_list):
    output_edgess = []
    for i in range(size):
        adj = []
        for edge in given_edge_list:
            if i in edge:
                adj.extend(edge)
        adjs = list(set(adj))
        if adjs != []:
            adjs.remove(i)
            sorted(adjs)
            adjs.insert(0, len(adjs))
            output_edgess.append(adjs)
    return output_edgess


new_list = []
for key,_ in counters.items():
    if eval(key)>1823:
        new_list.append(key)


new_counters = dict([(key,counters[key]) for key in new_list])

for key,item in tqdm(new_counters.items()):
    a = np.array(item["edges"])
    edge_list = a - np.min(a)

    #G = nx.Graph()
    #for e in edge_list:
    #    G.add_edge(e[0],e[1])
    #nx.draw_networkx(G)
    #plt.show()

    for query_size in query_size_list:
        a = [i for i in range(item["num_nodes"])]


        start_time = time.process_time()
        node_list = []
        while time.process_time()-start_time<=100 and node_list==[]:
            node_list = induced_node_list_generator(query_size,edge_list,a)
        if time.process_time() - start_time >= 100:
            with open("fail_query.txt", "a") as f:
                f.write("AID_query{}_size{}".format(key, query_size))
            continue
        node_list = sorted(node_list)
        sub_edge_list = []
        for e in edge_list:
            if e[0] in node_list and e[1] in node_list:
                sub_edge_list.append([node_list.index(e[0]),node_list.index(e[1])])
        output_edge = output_edge_list(query_size,sub_edge_list)
        for part in partition:
            output = output_edge.copy()
            c_nodes = query_size*part
            c_a = [i for i in range(query_size)]
            node_rank_list = induced_node_list_generator(c_nodes,sub_edge_list,c_a)
            for i in range(query_size):
                if i in node_rank_list:
                    output.append(["1"])
                else:
                    output.append(["0"])
            with open("query_graph/AID_query{}_size{}_part{}".format(key,query_size,part),"w") as f:
                f.write(str(query_size))
                f.write("\n")
                for edge in output:
                    for edge_item in edge:
                        f.write(str(edge_item))
                        f.write(" ")
                    f.write("\n")








