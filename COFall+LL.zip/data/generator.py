import networkx as nx
import os
import matplotlib.pyplot as plt












"""
edge_list = []
with open("edge_class.txt") as f:
    for line in f.readlines():
        line = line[:-1]
        edge_list.append(list(map(int,line.split(","))))

graph_idx = 0
edge_idx = 0
while graph_idx<2000:
    G = nx.DiGraph()
    while edge_list[edge_idx][2]==graph_idx:
        edge = edge_list[edge_idx]
        head,tail = edge_list[edge_idx][0],edge_list[edge_idx][1]
        G.add_edge(head, tail)
        edge_idx+=1
        if edge_idx>=len(edge_list):
            break
    nx.draw_networkx(G)
    plt.show()
    #plt.savefig("graph/{}.png".format(graph_idx))
    plt.close()
    graph_idx+=1

"""




